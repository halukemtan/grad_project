﻿using Entity.DTO_s;
using Entity.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Base_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntityDataController : ControllerBase
    {
        private readonly IEntityDataService _entityDataService;

        public EntityDataController(IEntityDataService entityDataService)
        {
            _entityDataService = entityDataService;
        }
        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAllEntityData()
        {
            var entities = await _entityDataService.GetAllEntities();
            if (entities == null)
            {
                return NotFound();
            }
            return Ok(entities);
        }
        [HttpDelete("Delete/{id}")]
        public IActionResult DeleteEntityData(int id)
        {
            try
            {
                if (id == 0)
                {
                    return NotFound();
                }
                _entityDataService.DeleteEntityData(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost("Create")]
        public async Task<IActionResult> CreateEntityData([FromBody] EntityDataDto entityDataDto)
        {
            var entity = await _entityDataService.CreateEntityData(entityDataDto);
            if (entity == null)
            {
                return NotFound();
            }
            return Ok(entity);
        }
        [HttpPut("Update")]
        public async Task<IActionResult> UpdateEntityData([FromBody] EntityDataDto entityDataDto)
        {
            var entity = await _entityDataService.UpdateEntityData(entityDataDto);
            if (entity == null)
            {
                return NotFound();
            }
            return Ok(entity);
        }
        [HttpGet("Get/{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var data = await _entityDataService.GetByIdAsync(id);
            if (data == null)
            {
                return NotFound(id);
            }
            return Ok(data);
        }
    }
}
