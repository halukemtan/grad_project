﻿using Microsoft.AspNetCore.Mvc;

namespace Base_API_UI.Controllers
{
    public class ErrorPageController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
