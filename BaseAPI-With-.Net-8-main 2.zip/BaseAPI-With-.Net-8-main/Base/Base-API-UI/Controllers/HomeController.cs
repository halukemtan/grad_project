﻿using Base_API_UI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
using static System.Net.WebRequestMethods;

namespace Base_API_UI.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public HomeController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var client = _httpClientFactory.CreateClient();
            var result = await client.GetAsync("https://localhost:7190/api/EntityData/GetAll");
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonData = await result.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<List<EntityDataViewModel>>(jsonData);
                return View(data);
            }
            return RedirectToAction("Index", "ErrorPage");
        }

        [HttpGet]
        public async Task<IActionResult> Update(int id)
        {
            var client = _httpClientFactory.CreateClient();
            var result = await client.GetAsync($"https://localhost:7190/api/EntityData/Get/{id}");
            var jsonData = await result.Content.ReadAsStringAsync();
            var data = JsonConvert.DeserializeObject<EntityDataViewModel>(jsonData);
            return View(data);
        }
        [HttpPost]
        public async Task<IActionResult> Update(EntityDataViewModel model)
        {
            var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(model);
            var content = new StringContent(jsonData, encoding: Encoding.UTF8, "application/json");
            var result = await client.PutAsync("https://localhost:7190/api/EntityData/Update", content);
            var error = await result.Content.ReadAsStringAsync();
            if(result.IsSuccessStatusCode)
            {
                var updateEntity = await result.Content.ReadAsStringAsync();
                var entityData = JsonConvert.DeserializeObject<EntityDataViewModel>(updateEntity);
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index", "ErrorPage");
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(EntityDataViewModel model)
        {
            var client = _httpClientFactory.CreateClient();
            var jsonData = JsonConvert.SerializeObject(model);
            var content = new StringContent(jsonData, encoding: Encoding.UTF8, "application/json");
            var result = await client.PostAsync("https://localhost:7190/api/EntityData/Create", content);
            if(result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index", "ErrorPage");
        }
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var client = _httpClientFactory.CreateClient();
            var result = await client.DeleteAsync($"https://localhost:7190/api/EntityData/Delete/{id}");
            var error = await result.Content.ReadAsStringAsync();

            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index", "ErrorPage");
        }
    }
}
