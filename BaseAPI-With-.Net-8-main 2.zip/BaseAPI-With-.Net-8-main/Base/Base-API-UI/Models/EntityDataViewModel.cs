﻿namespace Base_API_UI.Models
{
    public class EntityDataViewModel
    {
        public int Id { get; set; }
        public DateTime DateTime { get; set; } = DateTime.Now;
        public bool IsDeleted { get; set; }
        public decimal? Campere { get; set; }
        public decimal? Cwatt { get; set; }
        public decimal? TotalKwh { get; set; }
    }
}
