﻿using Entity.DTO_s;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Services
{
    public interface IEntityDataService
    {
        Task<string> CreateEntityData(EntityDataDto entityDataDto);
        Task<EntityDataDto> UpdateEntityData(EntityDataDto entityDataDto);
        string DeleteEntityData(int id);
        Task<List<EntityDataDto>> GetAllEntities();
        Task<EntityDataDto> GetByIdAsync(int id);

    }
}
