﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Entity
{
    public class EntityData : BaseEntity
    {
        public decimal? Campere { get; set; }
        public decimal? Cwatt { get; set; }
        public decimal? TotalKwh { get; set; }
    }
}
