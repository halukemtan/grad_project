﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.DTO_s
{
    public class EntityDataDto
    {
        public int Id { get; set; }
        public DateTime DateTime { get; set; } = DateTime.Now;
        public bool IsDeleted { get; set; }
        public decimal? Campere { get; set; }
        public decimal? Cwatt { get; set; }
        public decimal? TotalKwh { get; set; }
    }
}
