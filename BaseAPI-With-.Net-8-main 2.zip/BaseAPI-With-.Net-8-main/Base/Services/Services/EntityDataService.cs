﻿using AutoMapper;
using Entity.DTO_s;
using Entity.Entity;
using Entity.IUnitOfWork;
using Entity.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Services
{
    public class EntityDataService : IEntityDataService
    {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;

        public EntityDataService(IUnitOfWork uow, IMapper mapper)
        {
            _uow = uow;
            _mapper = mapper;
        }
        public async Task<string> CreateEntityData(EntityDataDto entityDataDto)
        {
            try
            {
                var mapperEntityData = _mapper.Map<EntityData>(entityDataDto);
                await _uow.GetRepository<EntityData>().Add(mapperEntityData);
                _uow.Commit();
                return "Ok";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string DeleteEntityData(int id)
        {
            try
            {
                _uow.GetRepository<EntityData>().DeleteById(id);
                _uow.Commit();
                return "Ok";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public async Task<List<EntityDataDto>> GetAllEntities()
        {
            try
            {
                var entityDatas = await _uow.GetRepository<EntityData>().GetAllAsync();
                return _mapper.Map<List<EntityDataDto>>(entityDatas);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<EntityDataDto> GetByIdAsync(int id)
        {
            try
            {
                var entityData = await _uow.GetRepository<EntityData>().GetById(id);
                var entityDataDto = new EntityDataDto()
                {
                    Campere = entityData.Campere,
                    Cwatt = entityData.Cwatt,
                    TotalKwh = entityData.TotalKwh,
                    DateTime = DateTime.Now,
                };
                return entityDataDto;
            }
            catch (Exception)
            {

                return null;
            }
        }

        public async Task<EntityDataDto> UpdateEntityData(EntityDataDto entityDataDto)
        {
            try
            {
                var oldEntityData = await _uow.GetRepository<EntityData>().Get(x => x.Id == entityDataDto.Id);
                oldEntityData.Campere = entityDataDto.Campere ?? oldEntityData.Campere;
                oldEntityData.Cwatt = entityDataDto.Cwatt ?? oldEntityData.Cwatt;
                oldEntityData.TotalKwh = entityDataDto.TotalKwh ?? oldEntityData.TotalKwh;
                oldEntityData.DateTime = entityDataDto.DateTime;
                _uow.GetRepository<EntityData>().Update(oldEntityData);
                _uow.Commit();
                return entityDataDto;

            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
