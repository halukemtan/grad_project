﻿using DataAccess.Repositories;
using DataAccess.UnitOfWork;
using Entity.IUnitOfWork;
using Entity.Repositories;
using Entity.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Services.Mapping;
using Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Extensions
{
    public static class DependencyExtensions
    {
        public static void AddExtensions(this IServiceCollection services, IConfiguration configuration)
        {
         
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));    
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IEntityDataService, EntityDataService>();
            services.AddAutoMapper(typeof(MappingProfile));

        }
    }
}
