String webpageCode = R"***(
<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> NODE MCU Web Server </title>
  <style>
    body {
        font-family: Arial, sans-serif;
        text-align: center;
        background-color: #f9f9f9;
    }
    h1 {
        color: #333;
    }
    .data-container {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
    }
    .data-box {
        background-color: #fff;
        border: 1px solid #ddd;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>
  <h1> NODE MCU Web Server </h1>
  <div class="data-container">
    <div class="data-box">
      <h2>İRMS</h2>
      <p>Anlık Amper: <span id="İRMS"></span></p>
    </div>
    <div class="data-box">
      <h2>Apparent Power</h2>
      <p>Anlık Güç: <span id="apparentPower"></span></p>
    </div>
    <div class="data-box">
      <h2>KW/H</h2>
      <p>Total Kw/h: <span id="kw/h"></span></p>
    </div>
  </div>

  <script>
    setInterval(function(){
      getJsonData();
    }, 250); // Her 2 saniyede bir bu fonksiyon çağırılacak

    function getJsonData(){
      var jsonRequest = new XMLHttpRequest(); // Sunucudan veri istemek için tarayıcıya izin verir
      jsonRequest.onreadystatechange = function()
      {
        if(this.readyState == 4 && this.status == 200)
        {
          var jsonData = JSON.parse(this.responseText); // Sunucudan gelen JSON verisini ayrıştırır
          document.getElementById("İRMS").innerHTML = jsonData.Campere;
          document.getElementById("apparentPower").innerHTML = jsonData.Cwatt;
          document.getElementById("kw/h").innerHTML = jsonData.totalkwh;
          
        }
      };
      jsonRequest.open("GET", "readData", true);
      jsonRequest.send();
    }
  </script>
</body>
</html>
)***";