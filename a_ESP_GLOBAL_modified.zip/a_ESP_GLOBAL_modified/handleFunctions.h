extern int webCounter;
extern String İRMS;
extern String apperentPower;
extern String kwh;
extern String jsonString;

void handleRoot(){
  espServer.send(200,"text/html",webpageCode);
}

void handleData(){ 
  espServer.send(200,"text/html",jsonString);
}


